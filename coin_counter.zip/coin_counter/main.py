import sys
import os

import torch
if hasattr(torch, 'serialization'):
    try:
        torch.serialization.add_safe_globals([
            'ultralytics.nn.tasks.DetectionModel',
            'ultralytics.nn.tasks.SegmentationModel', 
            'ultralytics.nn.tasks.ClassificationModel',
            'ultralytics.nn.tasks.PoseModel',
        ])
    except:
        pass

from PyQt5.QtWidgets import QApplication
from gui.main_window import CoinCounterWindow

def main():
    """Initialize and run the application"""
    app = QApplication(sys.argv)
    app.setApplicationName("Turkish Coin Counter")
    app.setOrganizationName("CoinDetection")
    
    # Set application style
    app.setStyle('Fusion')
    
    # Create and show main window
    window = CoinCounterWindow()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
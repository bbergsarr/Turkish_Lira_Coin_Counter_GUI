Complete step-by-step guide to set up and run the application.

📋 Prerequisites

System Requirements
Operating System: Windows 10/11, macOS 10.14+, or Linux
Python 3.8-3.12
RAM: Minimum 4GB (8GB recommended)
Storage: 2GB free space
GPU (Optional): NVIDIA GPU with CUDA support for faster inference

Software Requirements

Python 3.8-3.12
pip (Python package manager)
Git (optional, for cloning repository)

🔧 Step-by-Step Installation

Step 1: Check Python Installation
Open terminal/command prompt and verify Python version:

python --version
# or
python3 --version

Step 1.2: (If Python Version is 3.12+):

conda create -n coin_counter python=3.10

conda activate coin_counter

python --version
# Above command should print 3.10 as python version

Step 2:Manual Download

Download project ZIP file
Extract to desired location
Open terminal in extracted folder (IMPORTANT - GO TO DIRECTORY OF PROJECT)


Step 3: Create Virtual Environment (Recommended)

python -m venv venv
venv\Scripts\activate

Step 4: Install Dependencies

python -m pip install --upgrade pip

# Install Ultralytics + Pillow

pip uninstall ultralytics pillow -y

pip install ultralytics pillow

python -c "from PIL import Image; print(Image.__version__)"
# If the version can be seen after entering the command above, then its OK

# Install PyTorch CPU version first
pip uninstall torch torchvision
pip install torch==2.5.1 torchvision==0.20.1 --index-url https://download.pytorch.org/whl/cpu

# Then install other requirements
pip install PyQt5==5.15.9 opencv-python==4.8.1.78 ultralytics==8.0.200 numpy==1.26.0
pip install --upgrade ultralytics

Step 6: Run the Application

python main.py
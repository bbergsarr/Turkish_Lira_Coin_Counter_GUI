import cv2
import numpy as np
from ultralytics import YOLO
from pathlib import Path

class CoinDetector:
    """
    YOLO11-based coin detector for Turkish currency
    Supports detection of: 1TL, 50Kr, 25Kr, 10Kr, 5Kr, and foreign coins
    """
    
    # Turkish coin values in TL - ALL POSSIBLE VARIATIONS
    COIN_VALUES = {
        
        # 5 TL variations
        '5TL': 5.00,
        '5Lira': 5.00,
        '5TL': 5.00,        
        # 1 TL variations
        '1TL': 1.00,
        '1Lira': 1.00,
        '1TL': 1.00,
        
        # 50 Kuruş variations
        '50Kr': 0.50,
        '50 Kr': 0.50,
        '50Kuruş': 0.50,
        '50 Kuruş': 0.50,
        '50Kurus': 0.50,
        
        # 25 Kuruş variations
        '25Kr': 0.25,
        '25 Kr': 0.25,
        '25Kuruş': 0.25,
        '25 Kuruş': 0.25,
        '25Kurus': 0.25,
        
        # 10 Kuruş variations
        '10Kr': 0.10,
        '10 Kr': 0.10,
        '10Kuruş': 0.10,
        '10 Kuruş': 0.10,
        '10Kurus': 0.10,
        
        # 5 Kuruş variations
        '5Kr': 0.05,
        '5 Kr': 0.05,
        '5Kuruş': 0.05,
        '5 Kuruş': 0.05,
        '5Kurus': 0.05,
        # 1 Kuruş variations
        '1Kr': 0.01,
        '1 Kr': 0.01,
        '1Kuruş': 0.01,
        '1 Kuruş': 0.01,
        '1Kurus': 0.01,
        
        # Foreign coins
        'Foreign': 0.00,
        'Yabanci': 0.00,
        'Yabancı': 0.00
    }
    
    # Normalize class names to standard format for display
    CLASS_NORMALIZATION = {
        '5 TL': '5TL',
        '1 TL': '1TL',
        '50 Kr': '50Kr',
        '50Kuruş': '50Kr',
        '50 Kuruş': '50Kr',
        '50Kurus': '50Kr',
        '25 Kr': '25Kr',
        '25Kuruş': '25Kr',
        '25 Kuruş': '25Kr',
        '25Kurus': '25Kr',
        '10 Kr': '10Kr',
        '10Kuruş': '10Kr',
        '10 Kuruş': '10Kr',
        '10Kurus': '10Kr',
        '5 Kr': '5Kr',
        '5Kuruş': '5Kr',
        '5 Kuruş': '5Kr',
        '5Kurus': '5Kr',
        '1 Kr': '1Kr',
        '1Kuruş': '1Kr',
        '1 Kuruş': '1Kr',
        '1Kurus': '1Kr',
        'Yabanci': 'Foreign',
        'Yabancı': 'Foreign'
    }
    
    # Colors for visualization (BGR format)
    COLORS = {
        '5TL': (0, 255, 255),      # Yellow
        '1TL': (0, 215, 255),      # Gold
        '50Kr': (203, 192, 255),   # Light pink
        '25Kr': (180, 180, 180),   # Silver
        '10Kr': (140, 140, 140),   # Dark silver
        '5Kr': (100, 100, 100),    # Darker silver
        '1Kr': (50, 50, 50),       #Gray
        'Foreign': (0, 0, 255)     # Red
    }
    
    def __init__(self, model_path, conf_threshold=0.40, iou_threshold=0.50):
        """
        Initialize the coin detector
        
        Args:
            model_path: Path to trained YOLO11 .pt file
            conf_threshold: Confidence threshold (default: 0.40)
            iou_threshold: IOU threshold for NMS (default: 0.50)
        """
        self.model_path = Path(model_path)
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold
        self.model = None
        
        self._load_model()
    
    def _load_model(self):
        """Load the YOLO11 model with PyTorch 2.6+ compatibility"""
        if not self.model_path.exists():
            raise FileNotFoundError(f"Model file not found: {self.model_path}")
        
        try:
            # For PyTorch 2.6+, set weights_only=False to load YOLO models
            import torch
            if hasattr(torch, 'serialization'):
                torch.serialization.add_safe_globals([
                    'ultralytics.nn.tasks.SegmentationModel',
                    'ultralytics.nn.tasks.DetectionModel',
                    'ultralytics.nn.tasks.ClassificationModel',
                    'ultralytics.nn.tasks.PoseModel',
                ])
            
            self.model = YOLO(str(self.model_path))
            print(f"✓ Model loaded successfully: {self.model_path.name}")
        except Exception as e:
            raise RuntimeError(f"Failed to load model: {str(e)}")
    
    def normalize_class_name(self, class_name):
        """
        Normalize class name to standard format for consistent display
        Example: '50 Kuruş' -> '50Kr', '1 TL' -> '1TL'
        """
        return self.CLASS_NORMALIZATION.get(class_name, class_name)
    
    def get_coin_value(self, class_name):
        """
        Get coin value, handles all variations
        Returns value in TL (e.g., 0.50 for 50 Kuruş)
        """
        # Try to get value directly first
        value = self.COIN_VALUES.get(class_name, None)
        
        # If not found, try normalized version
        if value is None:
            normalized = self.normalize_class_name(class_name)
            value = self.COIN_VALUES.get(normalized, 0.0)
        
        return value
    
    def filter_overlapping_detections(self, boxes, confidences, class_ids, iou_threshold=0.3):
        """
        Remove overlapping detections with lower confidence
        This helps eliminate phantom detections
        
        Args:
            boxes: List of bounding boxes [x1, y1, x2, y2]
            confidences: List of confidence scores
            class_ids: List of class IDs
            iou_threshold: IOU threshold for considering boxes as overlapping
        
        Returns:
            Filtered indices to keep
        """
        if len(boxes) == 0:
            return []
        
        # Convert to numpy arrays
        boxes = np.array(boxes)
        confidences = np.array(confidences)
        class_ids = np.array(class_ids)
        
        # Calculate areas
        x1 = boxes[:, 0]
        y1 = boxes[:, 1]
        x2 = boxes[:, 2]
        y2 = boxes[:, 3]
        areas = (x2 - x1) * (y2 - y1)
        
        # Sort by confidence (descending)
        order = confidences.argsort()[::-1]
        
        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            
            if order.size == 1:
                break
            
            # Calculate IOU with remaining boxes
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])
            
            w = np.maximum(0.0, xx2 - xx1)
            h = np.maximum(0.0, yy2 - yy1)
            intersection = w * h
            
            iou = intersection / (areas[i] + areas[order[1:]] - intersection)
            
            # Keep boxes with IOU less than threshold
            inds = np.where(iou <= iou_threshold)[0]
            order = order[inds + 1]
        
        return keep
    
    def filter_low_quality_detections(self, detections):
        """
        Filter out low quality detections based on multiple criteria:
        1. Very small boxes (likely noise)
        2. Very large boxes (likely background)
        3. Aspect ratio check (coins should be roughly circular)
        
        Args:
            detections: List of detection dictionaries
        
        Returns:
            Filtered list of detections
        """
        filtered = []
        
        for det in detections:
            x1, y1, x2, y2 = det['bbox']
            width = x2 - x1
            height = y2 - y1
            area = width * height
            
            # Filter 1: Remove very small detections (< 400 pixels)
            if area < 400:
                continue
            
            # Filter 2: Aspect ratio check (coins should be roughly square/circular)
            aspect_ratio = width / height if height > 0 else 0
            if aspect_ratio < 0.5 or aspect_ratio > 2.0:
                continue
            
            # Filter 3: Double check confidence threshold
            if det['confidence'] < 0.30:
                continue
            
            filtered.append(det)
        
        return filtered
    
    def detect(self, image, preprocess=True):
        """
        Detect coins in an image
        
        Args:
            image: Input image (numpy array, BGR format)
            preprocess: Whether to apply preprocessing (default: True)
        
        Returns:
            results: YOLO detection results object
        """
        if self.model is None:
            raise RuntimeError("Model not loaded")
        
        # Run inference with confidence threshold
        results = self.model.predict(
            image,
            imgsz=1280,
            conf=self.conf_threshold,
            iou=self.iou_threshold,
            verbose=False,
            agnostic_nms=True  # Enable class-agnostic NMS
        )
        
        return results[0]
    
    def process_results(self, results):
        """
        Process YOLO results and extract detection information
        FIXED: Now properly calculates total value for all detected coins
        
        Args:
            results: YOLO detection results
        
        Returns:
            detections: List of detection dictionaries
            total_value: Total monetary value (TL) - PROPERLY CALCULATED
        """
        detections = []
        
        if results.boxes is None or len(results.boxes) == 0:
            return detections, 0.0
        
        boxes = results.boxes.xyxy.cpu().numpy()  # Bounding boxes
        confidences = results.boxes.conf.cpu().numpy()  # Confidence scores
        class_ids = results.boxes.cls.cpu().numpy().astype(int)  # Class IDs
        
        # Get class names from model
        class_names = results.names
        
        # Filter overlapping detections first
        keep_indices = self.filter_overlapping_detections(
            boxes, confidences, class_ids, iou_threshold=0.3
        )
        
        # Create detections with proper value assignment
        for i in keep_indices:
            box = boxes[i]
            conf = confidences[i]
            cls_id = class_ids[i]
            
            x1, y1, x2, y2 = box
            raw_class_name = class_names[cls_id]
            
            # Get the actual coin value (handles all variations)
            coin_value = self.get_coin_value(raw_class_name)
            
            # Normalize class name for display consistency
            normalized_class_name = self.normalize_class_name(raw_class_name)
            
            detection = {
                'id': i,
                'bbox': (int(x1), int(y1), int(x2), int(y2)),
                'confidence': float(conf),
                'class_id': int(cls_id),
                'class_name': normalized_class_name,  # For display
                'raw_class_name': raw_class_name,     # Original from model
                'value': coin_value  # IMPORTANT: Actual monetary value
            }
            
            detections.append(detection)
        
        # Apply quality filtering
        detections = self.filter_low_quality_detections(detections)
        
        # CRITICAL FIX: Calculate total value by summing ALL detected coin values
        total_value = 0.0
        for det in detections:
            coin_value = det['value']
            total_value += coin_value
            print(f"DEBUG: Adding {det['class_name']} = {coin_value} TL (Total so far: {total_value} TL)")
        
        print(f"DEBUG: Final total = {total_value} TL from {len(detections)} coins")
        
        return detections, total_value
    
    def draw_detections(self, image, detections, show_confidence=True):
        """
        Draw bounding boxes and labels on image
        
        Args:
            image: Input image (numpy array)
            detections: List of detection dictionaries
            show_confidence: Whether to show confidence scores
        
        Returns:
            annotated_image: Image with drawn detections
        """
        annotated = image.copy()
        
        for det in detections:
            x1, y1, x2, y2 = det['bbox']
            class_name = det['class_name']
            conf = det['confidence']
            value = det['value']
            
            # Get color for this class
            color = self.COLORS.get(class_name, (255, 255, 255))
            
            # Draw bounding box with thicker line
            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 3)
            
            # Prepare label with value
            if show_confidence:
                label = f"{class_name} {value:.2f}TL ({conf:.2f})"
            else:
                label = f"{class_name} ({value:.2f}TL)"
            
            # Calculate label size and position
            (label_w, label_h), baseline = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2
            )
            
            # Draw label background
            cv2.rectangle(
                annotated,
                (x1, y1 - label_h - baseline - 10),
                (x1 + label_w + 10, y1),
                color,
                -1
            )
            
            # Draw label text
            cv2.putText(
                annotated,
                label,
                (x1 + 5, y1 - baseline - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 0, 0),
                2
            )
        
        return annotated
    
    def get_detection_summary(self, detections, total_value):
        """
        Generate a summary of detections with PROPER value calculations
        
        Args:
            detections: List of detection dictionaries
            total_value: Total monetary value (already calculated correctly)
        
        Returns:
            summary: Dictionary with detection statistics
        """
        # Count coins by type
        coin_counts = {}
        for det in detections:
            class_name = det['class_name']
            coin_counts[class_name] = coin_counts.get(class_name, 0) + 1
        
        # Calculate value by type (sum of actual values)
        value_by_type = {}
        for det in detections:
            class_name = det['class_name']
            value = det['value']
            value_by_type[class_name] = value_by_type.get(class_name, 0.0) + value
        
        # Verify total matches sum
        calculated_total = sum(value_by_type.values())
        
        summary = {
            'total_coins': len(detections),
            'total_value': total_value,  # Use the passed total
            'calculated_total': calculated_total,  # For verification
            'coin_counts': coin_counts,
            'value_by_type': value_by_type,
            'average_confidence': np.mean([d['confidence'] for d in detections]) if detections else 0.0,
            'min_confidence': np.min([d['confidence'] for d in detections]) if detections else 0.0,
            'max_confidence': np.max([d['confidence'] for d in detections]) if detections else 0.0
        }
        
        print(f"DEBUG Summary: {len(detections)} coins, Total: {total_value} TL")
        print(f"DEBUG Breakdown: {value_by_type}")
        
        return summary
    
    def detect_and_process(self, image):
        """
        Complete detection pipeline: detect + process + annotate
        
        Args:
            image: Input image (numpy array)
        
        Returns:
            annotated_image: Image with drawn detections
            detections: List of detection dictionaries
            summary: Detection summary dictionary
        """
        # Run detection
        results = self.detect(image)
        
        # Process results (this now correctly calculates total)
        detections, total_value = self.process_results(results)
        
        # Draw detections
        annotated_image = self.draw_detections(image, detections)
        
        # Get summary (uses the correct total_value)
        summary = self.get_detection_summary(detections, total_value)
        
        return annotated_image, detections, summary
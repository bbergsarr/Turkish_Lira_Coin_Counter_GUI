import os
import sys
from pathlib import Path

def create_directories():
    """Create necessary project directories"""
    directories = [
        'models',
        'test_images',
        'utils',
        'gui'
    ]
    
    print("Creating project directories...")
    for dir_name in directories:
        Path(dir_name).mkdir(exist_ok=True)
        print(f"  ✓ {dir_name}/")
    
    # Create __init__.py files
    init_files = [
        'utils/__init__.py',
        'gui/__init__.py'
    ]
    
    for init_file in init_files:
        Path(init_file).touch(exist_ok=True)
    
    print("\n✓ Directory structure created successfully!")

def check_dependencies():
    """Check if required packages are installed"""
    print("\nChecking dependencies...")
    
    required_packages = {
        'PyQt5': 'PyQt5',
        'cv2': 'opencv-python',
        'numpy': 'numpy',
        'ultralytics': 'ultralytics',
        'torch': 'torch'
    }
    
    missing = []
    for module, package in required_packages.items():
        try:
            __import__(module)
            print(f"  ✓ {package}")
        except ImportError:
            print(f"  ✗ {package} (missing)")
            missing.append(package)
    
    if missing:
        print(f"\n⚠ Missing packages: {', '.join(missing)}")
        print("Install with: pip install -r requirements.txt")
        return False
    else:
        print("\n✓ All dependencies are installed!")
        return True

def check_model():
    """Check if model file exists"""
    print("\nChecking for model file...")
    
    models_dir = Path('models')
    pt_files = list(models_dir.glob('*.pt'))
    
    if pt_files:
        print(f"  ✓ Found model: {pt_files[0].name}")
        return True
    else:
        print("  ✗ No .pt model file found in models/ directory")
        print("\n⚠ Please place your trained YOLO11n model (.pt file) in the models/ folder")
        return False

def main():
    """Main setup function"""
    print("=" * 60)
    print("Turkish Coin Counter - Setup")
    print("=" * 60)
    
    # Create directories
    create_directories()
    
    # Check dependencies
    deps_ok = check_dependencies()
    
    # Check model
    model_ok = check_model()
    
    print("\n" + "=" * 60)
    if deps_ok and model_ok:
        print("✓ Setup complete! You can now run: python main.py")
    elif deps_ok:
        print("⚠ Setup incomplete - please add your model file")
        print("  Then run: python main.py")
    else:
        print("⚠ Setup incomplete - please install dependencies first")
        print("  Run: pip install -r requirements.txt")
    print("=" * 60)

if __name__ == '__main__':
    main()
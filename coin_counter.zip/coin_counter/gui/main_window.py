import cv2
import numpy as np
from pathlib import Path
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QFileDialog, QComboBox, QGroupBox, QScrollArea,
    QMessageBox, QSplitter, QTextEdit, QFrame
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QImage, QPixmap, QFont

from utils.preprocessor import CoinPreprocessor
from utils.detector import CoinDetector


class ZoomableScrollArea(QScrollArea):
    """ScrollArea with mouse wheel zoom support"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.zoom_callback = None  # Will be set by parent

    def wheelEvent(self, event):
        if event.modifiers() == Qt.ControlModifier:
            # Ctrl + Scroll → zoom
            delta = event.angleDelta().y()
            if self.zoom_callback:
                if delta > 0:
                    self.zoom_callback(1.15)   # zoom in
                else:
                    self.zoom_callback(1 / 1.15)  # zoom out
            event.accept()
        else:
            super().wheelEvent(event)


class DetectionThread(QThread):
    """Background thread for coin detection to keep GUI responsive"""

    finished = pyqtSignal(object, object, object)  # annotated_image, detections, summary
    error = pyqtSignal(str)

    def __init__(self, detector, preprocessor, image, preprocess_mode):
        super().__init__()
        self.detector = detector
        self.preprocessor = preprocessor
        self.image = image
        self.preprocess_mode = preprocess_mode

    def run(self):
        """Run detection in background"""
        try:
            if self.preprocess_mode != 'none':
                processed_image, _, _ = self.preprocessor.preprocess(
                    self.image, mode=self.preprocess_mode
                )
            else:
                processed_image = self.image

            annotated_image, detections, summary = self.detector.detect_and_process(
                processed_image
            )

            self.finished.emit(annotated_image, detections, summary)

        except Exception as e:
            self.error.emit(str(e))


class CoinCounterWindow(QMainWindow):
    """Main application window"""

    def __init__(self):
        super().__init__()
        self.current_image = None
        self.current_image_path = None
        self.detector = None
        self.preprocessor = CoinPreprocessor(target_size=640)
        self.detection_thread = None

        # Zoom state
        self.zoom_factor = 1.0
        self.original_pixmap = None   # stored pixmap for original image
        self.result_pixmap = None     # stored pixmap for result image

        self.init_ui()
        self.load_model()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def init_ui(self):
        """Initialize user interface"""
        self.setWindowTitle("Turkish Coin Counter - YOLO11n")
        self.setGeometry(100, 100, 1400, 900)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(10, 10, 10, 10)

        # Title
        title_label = QLabel("Turkish Coin Counter")
        title_font = QFont()
        title_font.setPointSize(18)
        title_font.setBold(True)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)

        # Controls
        control_group = self.create_control_panel()
        main_layout.addWidget(control_group)

        # Image splitter
        splitter = QSplitter(Qt.Horizontal)

        original_panel = self.create_image_panel("Original Image", is_original=True)
        splitter.addWidget(original_panel)

        result_panel = self.create_image_panel("Detection Result", is_original=False)
        splitter.addWidget(result_panel)

        splitter.setSizes([700, 700])
        main_layout.addWidget(splitter, stretch=1)

        # Results panel
        results_group = self.create_results_panel()
        results_group.setMaximumHeight(220)
        main_layout.addWidget(results_group)

        self.statusBar().showMessage("Ready  |  Ctrl + Scroll: zoom  |  Zoom buttons in toolbar")

    def create_control_panel(self):
        """Create control buttons and settings panel"""
        group = QGroupBox("Controls")
        layout = QHBoxLayout()

        # Load image button
        self.btn_load = QPushButton("Load Image")
        self.btn_load.setMinimumHeight(40)
        self.btn_load.clicked.connect(self.load_image)
        layout.addWidget(self.btn_load)

        # Preprocessing mode selector
        layout.addWidget(QLabel("Preprocessing:"))
        self.combo_preprocess = QComboBox()
        self.combo_preprocess.addItems([
            'none', 'fast', 'balanced', 'quality', 'small_coins'
        ])
        self.combo_preprocess.setCurrentText('balanced')
        self.combo_preprocess.setMinimumWidth(150)
        self.combo_preprocess.setToolTip(
            "none: No preprocessing\n"
            "fast: ~5-10ms, real-time\n"
            "balanced: ~15-25ms, general use (recommended)\n"
            "quality: ~30-40ms, maximum accuracy\n"
            "small_coins: ~20-30ms, optimized for 5-10-25 Kuruş"
        )
        layout.addWidget(self.combo_preprocess)

        # Confidence threshold selector
        layout.addWidget(QLabel("Confidence:"))
        self.combo_confidence = QComboBox()
        self.combo_confidence.addItems([
            '0.30 (More detections)',
            '0.35 (Balanced)',
            '0.40 (Default)',
            '0.45 (Conservative)',
            '0.50 (Very strict)'
        ])
        self.combo_confidence.setCurrentText('0.40 (Default)')
        self.combo_confidence.setMinimumWidth(180)
        self.combo_confidence.setToolTip(
            "Lower values: More coins detected but may include false positives\n"
            "Higher values: Fewer false positives but might miss some coins\n"
            "Recommended: 0.40 for balanced results"
        )
        self.combo_confidence.currentTextChanged.connect(self.update_confidence_threshold)
        layout.addWidget(self.combo_confidence)

        # Detect button
        self.btn_detect = QPushButton("Detect Coins")
        self.btn_detect.setMinimumHeight(40)
        self.btn_detect.setEnabled(False)
        self.btn_detect.setStyleSheet("background-color: #4CAF50; color: white;")
        self.btn_detect.clicked.connect(self.detect_coins)
        layout.addWidget(self.btn_detect)

        # Clear button
        self.btn_clear = QPushButton("Clear")
        self.btn_clear.setMinimumHeight(40)
        self.btn_clear.clicked.connect(self.clear_all)
        layout.addWidget(self.btn_clear)

        # ── Zoom controls ──────────────────────────────────────────────
        layout.addWidget(self._vline())

        self.lbl_zoom = QLabel("Zoom: 100%")
        self.lbl_zoom.setMinimumWidth(90)
        layout.addWidget(self.lbl_zoom)

        btn_zoom_in = QPushButton("🔍 +")
        btn_zoom_in.setMinimumHeight(40)
        btn_zoom_in.setMinimumWidth(55)
        btn_zoom_in.setToolTip("Zoom in  (Ctrl + Scroll also works)")
        btn_zoom_in.clicked.connect(lambda: self.apply_zoom(1.25))
        layout.addWidget(btn_zoom_in)

        btn_zoom_out = QPushButton("🔍 −")
        btn_zoom_out.setMinimumHeight(40)
        btn_zoom_out.setMinimumWidth(55)
        btn_zoom_out.setToolTip("Zoom out  (Ctrl + Scroll also works)")
        btn_zoom_out.clicked.connect(lambda: self.apply_zoom(1 / 1.25))
        layout.addWidget(btn_zoom_out)

        btn_zoom_reset = QPushButton("⟳ Fit")
        btn_zoom_reset.setMinimumHeight(40)
        btn_zoom_reset.setMinimumWidth(65)
        btn_zoom_reset.setToolTip("Reset zoom to fit window")
        btn_zoom_reset.clicked.connect(self.reset_zoom)
        layout.addWidget(btn_zoom_reset)
        # ───────────────────────────────────────────────────────────────

        layout.addStretch()
        group.setLayout(layout)
        return group

    @staticmethod
    def _vline():
        """Thin vertical separator widget"""
        line = QFrame()
        line.setFrameShape(QFrame.VLine)
        line.setFrameShadow(QFrame.Sunken)
        return line

    def create_image_panel(self, title, is_original=True):
        """Create image display panel with zoomable scroll area"""
        group = QGroupBox(title)
        layout = QVBoxLayout()

        scroll = ZoomableScrollArea()
        scroll.setWidgetResizable(False)          # ← must be False for zoom to work
        scroll.setAlignment(Qt.AlignCenter)

        image_label = QLabel()
        image_label.setAlignment(Qt.AlignCenter)
        image_label.setMinimumSize(800, 600)
        image_label.setStyleSheet("background-color: #f0f0f0; border: 1px solid #ccc;")
        image_label.setText("No image loaded")

        scroll.setWidget(image_label)
        # Hook mouse-wheel zoom into this scroll area
        scroll.zoom_callback = self.apply_zoom
        layout.addWidget(scroll)

        if is_original:
            self.label_original = image_label
            self.scroll_original = scroll
        else:
            self.label_result = image_label
            self.scroll_result = scroll

        group.setLayout(layout)
        return group

    def create_results_panel(self):
        """Create results display panel"""
        group = QGroupBox("Detection Results")
        layout = QHBoxLayout()

        summary_layout = QVBoxLayout()

        self.label_total_coins = QLabel("Total Coins: 0")
        self.label_total_coins.setFont(QFont("Arial", 14, QFont.Bold))
        summary_layout.addWidget(self.label_total_coins)

        self.label_total_value = QLabel("Total Value: 0.00 TL")
        self.label_total_value.setFont(QFont("Arial", 16, QFont.Bold))
        self.label_total_value.setStyleSheet("color: #2E7D32;")
        summary_layout.addWidget(self.label_total_value)

        self.label_avg_conf = QLabel("Avg. Confidence: 0.00")
        summary_layout.addWidget(self.label_avg_conf)

        summary_layout.addStretch()
        layout.addLayout(summary_layout)

        self.text_details = QTextEdit()
        self.text_details.setReadOnly(True)
        self.text_details.setMaximumHeight(150)
        layout.addWidget(self.text_details, stretch=1)

        group.setLayout(layout)
        return group

    # ------------------------------------------------------------------
    # Zoom logic
    # ------------------------------------------------------------------

    def apply_zoom(self, factor):
        """Multiply current zoom by factor and refresh both images"""
        self.zoom_factor = max(0.2, min(self.zoom_factor * factor, 8.0))
        self.lbl_zoom.setText(f"Zoom: {int(self.zoom_factor * 100)}%")
        self._refresh_images()

    def reset_zoom(self):
        """Reset zoom to 1.0 (fit-to-label baseline)"""
        self.zoom_factor = 1.0
        self.lbl_zoom.setText("Zoom: 100%")
        self._refresh_images()

    def _refresh_images(self):
        """Re-render stored pixmaps at current zoom level"""
        if self.original_pixmap:
            self._set_zoomed(self.original_pixmap, self.label_original, self.scroll_original)
        if self.result_pixmap:
            self._set_zoomed(self.result_pixmap, self.label_result, self.scroll_result)

    def _set_zoomed(self, pixmap, label, scroll):
        """Scale pixmap by zoom_factor and update label size so scroll bars appear"""
        base_w = scroll.viewport().width()
        base_h = scroll.viewport().height()

        # At zoom=1 the image fits the viewport; beyond that it grows
        target_w = int(base_w * self.zoom_factor)
        target_h = int(base_h * self.zoom_factor)

        scaled = pixmap.scaled(
            target_w, target_h,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )

        label.setPixmap(scaled)
        label.resize(scaled.size())      # let scroll area know the new size

    # ------------------------------------------------------------------
    # Model / image helpers
    # ------------------------------------------------------------------

    def load_model(self):
        """Load YOLO11 model"""
        model_dir = Path("models")
        if not model_dir.exists():
            model_dir.mkdir(parents=True)

        pt_files = list(model_dir.glob("*.pt"))

        if not pt_files:
            QMessageBox.warning(
                self,
                "Model Not Found",
                "No .pt model file found in 'models' directory.\n"
                "Please place your trained YOLO11 model (.pt file) in the 'models' folder."
            )
            self.statusBar().showMessage("Model not loaded - place .pt file in models/ folder")
            return

        model_path = pt_files[0]

        try:
            self.detector = CoinDetector(
                str(model_path),
                conf_threshold=0.40,
                iou_threshold=0.50
            )
            self.statusBar().showMessage(f"Model loaded: {model_path.name}")
            QMessageBox.information(
                self,
                "Model Loaded",
                f"Successfully loaded model: {model_path.name}\n\n"
                f"Confidence Threshold: 0.40 (adjustable in controls)"
            )
        except Exception as e:
            QMessageBox.critical(self, "Model Loading Error", f"Failed to load model: {str(e)}")
            self.statusBar().showMessage("Model loading failed")

    def update_confidence_threshold(self, text):
        if self.detector is None:
            return
        conf_value = float(text.split()[0])
        self.detector.conf_threshold = conf_value
        self.statusBar().showMessage(f"Confidence threshold updated to {conf_value}")

    def load_image(self):
        """Load image from file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Image", "",
            "Image Files (*.png *.jpg *.jpeg *.bmp);;All Files (*)"
        )
        if not file_path:
            return

        try:
            self.current_image = cv2.imread(file_path)
            if self.current_image is None:
                raise ValueError("Failed to read image")

            self.current_image_path = file_path
            self.display_image(self.current_image, self.label_original, store_as='original')

            self.label_result.clear()
            self.label_result.setText("Click 'Detect Coins' to analyze")
            self.result_pixmap = None

            self.btn_detect.setEnabled(True)
            self.statusBar().showMessage(f"Image loaded: {Path(file_path).name}")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load image: {str(e)}")

    def detect_coins(self):
        """Perform coin detection"""
        if self.current_image is None:
            QMessageBox.warning(self, "Warning", "Please load an image first")
            return
        if self.detector is None:
            QMessageBox.warning(
                self, "Warning",
                "Model not loaded. Please place your .pt file in models/ folder and restart."
            )
            return

        self.btn_detect.setEnabled(False)
        self.statusBar().showMessage("Detecting coins...")

        preprocess_mode = self.combo_preprocess.currentText()

        self.detection_thread = DetectionThread(
            self.detector, self.preprocessor, self.current_image, preprocess_mode
        )
        self.detection_thread.finished.connect(self.on_detection_finished)
        self.detection_thread.error.connect(self.on_detection_error)
        self.detection_thread.start()

    def on_detection_finished(self, annotated_image, detections, summary):
        """Handle detection completion"""
        self.display_image(annotated_image, self.label_result, store_as='result')

        total_coins = summary['total_coins']
        total_value = summary['total_value']

        self.label_total_coins.setText(f"Total Coins: {total_coins}")
        self.label_total_value.setText(f"Total Value: {total_value:.2f} TL")
        self.label_avg_conf.setText(f"Avg. Confidence: {summary['average_confidence']:.2%}")

        details = "Detection Summary:\n"
        details += "=" * 50 + "\n\n"
        details += "Detected Coins:\n"
        for class_name in sorted(summary['coin_counts'].keys()):
            count = summary['coin_counts'][class_name]
            value_per_coin = self.detector.get_coin_value(class_name)
            subtotal = summary['value_by_type'].get(class_name, 0.0)
            details += f"  • {class_name}: {count} coin(s) × {value_per_coin:.2f} TL = {subtotal:.2f} TL\n"

        details += "\n" + "-" * 50 + "\n"
        details += f"TOTAL: {total_value:.2f} TL ({total_coins} coins)\n"
        details += "-" * 50 + "\n\n"
        details += "Confidence Statistics:\n"
        details += f"  • Average: {summary['average_confidence']:.2%}\n"
        details += f"  • Minimum: {summary.get('min_confidence', 0):.2%}\n"
        details += f"  • Maximum: {summary.get('max_confidence', 0):.2%}\n"

        if 'calculated_total' in summary:
            details += f"\n[Debug] Calculated total: {summary['calculated_total']:.2f} TL\n"

        self.text_details.setText(details)

        self.btn_detect.setEnabled(True)
        self.statusBar().showMessage(
            f"Detection complete: {total_coins} coins, {total_value:.2f} TL  |  "
            f"Ctrl+Scroll or use 🔍 buttons to zoom"
        )

    def on_detection_error(self, error_msg):
        QMessageBox.critical(self, "Detection Error", f"Error during detection: {error_msg}")
        self.btn_detect.setEnabled(True)
        self.statusBar().showMessage("Detection failed")

    def display_image(self, cv_image, label, store_as=None):
        """Convert OpenCV image → QPixmap, store it, then render at current zoom"""
        rgb_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        qt_image = QImage(rgb_image.data, w, h, ch * w, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image)

        if store_as == 'original':
            self.original_pixmap = pixmap
            self._set_zoomed(pixmap, self.label_original, self.scroll_original)
        elif store_as == 'result':
            self.result_pixmap = pixmap
            self._set_zoomed(pixmap, self.label_result, self.scroll_result)
        else:
            # fallback: scale to fit label (no zoom)
            scaled = pixmap.scaled(label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            label.setPixmap(scaled)

    def clear_all(self):
        """Clear all images and results"""
        self.current_image = None
        self.current_image_path = None
        self.original_pixmap = None
        self.result_pixmap = None
        self.zoom_factor = 1.0
        self.lbl_zoom.setText("Zoom: 100%")

        self.label_original.clear()
        self.label_original.setText("No image loaded")
        self.label_result.clear()
        self.label_result.setText("No results")

        self.label_total_coins.setText("Total Coins: 0")
        self.label_total_value.setText("Total Value: 0.00 TL")
        self.label_avg_conf.setText("Avg. Confidence: 0.00")
        self.text_details.clear()

        self.btn_detect.setEnabled(False)
        self.statusBar().showMessage("Cleared")
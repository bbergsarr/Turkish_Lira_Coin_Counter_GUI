Program yükleme adımları adım adım uygulanmalıdır.
Virtual Env. içinde kurulması tavsiye olunur.
pip indirmeleri eksik ve hatalıysa düzeltilmelidir.
tek seferlik kurulum yapıldıktan sonra tekrar kurmaya ihtiyaç olmaz.
Sürekli girişlerde virtual env. açılır ve aktif edilip main.py dosyası çalıştırılır.